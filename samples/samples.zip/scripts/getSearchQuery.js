output.result = 'qwerty';
